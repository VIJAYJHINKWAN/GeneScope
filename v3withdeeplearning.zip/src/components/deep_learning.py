import copy

import numpy as np
import torch
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.model_selection import train_test_split
from torch import nn


class DeepNeuralNetworkClassifier(ClassifierMixin, BaseEstimator):
    """
    Deep learning model: a fully connected neural network built with PyTorch.

    Architecture (default):
        input (12 features + missing flags)
        -> Dense 128 -> BatchNorm -> ReLU -> Dropout
        -> Dense 64  -> BatchNorm -> ReLU -> Dropout
        -> Dense 32  -> BatchNorm -> ReLU -> Dropout
        -> Dense 5 (one output per disease, softmax)

    Trained with the Adam optimizer and cross-entropy loss. A part of the
    training data is kept for validation, and training stops early when the
    validation loss stops improving (the best weights are restored).

    It follows the scikit-learn interface (fit / predict / predict_proba),
    so it is cross-validated, compared and saved exactly like the other models.
    """

    def __init__(
        self,
        hidden_layers=(128, 64, 32),
        dropout=0.2,
        learning_rate=1e-3,
        weight_decay=1e-4,
        batch_size=32,
        max_epochs=300,
        patience=25,
        validation_fraction=0.15,
        random_state=42,
    ):
        self.hidden_layers = hidden_layers
        self.dropout = dropout
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.batch_size = batch_size
        self.max_epochs = max_epochs
        self.patience = patience
        self.validation_fraction = validation_fraction
        self.random_state = random_state

    def _build_network(self, n_inputs: int, n_outputs: int) -> nn.Sequential:
        layers = []
        size = n_inputs
        for units in self.hidden_layers:
            layers += [
                nn.Linear(size, units),
                nn.BatchNorm1d(units),
                nn.ReLU(),
                nn.Dropout(self.dropout),
            ]
            size = units
        layers.append(nn.Linear(size, n_outputs))
        return nn.Sequential(*layers)

    def fit(self, X, y):
        torch.manual_seed(self.random_state)
        torch.set_num_threads(1)

        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        self.n_features_in_ = X.shape[1]
        y_index = np.searchsorted(self.classes_, y)

        X_train, X_val, y_train, y_val = train_test_split(
            X,
            y_index,
            test_size=self.validation_fraction,
            stratify=y_index,
            random_state=self.random_state,
        )
        X_train, y_train = torch.from_numpy(X_train), torch.from_numpy(y_train).long()
        X_val, y_val = torch.from_numpy(X_val), torch.from_numpy(y_val).long()

        self.network_ = self._build_network(X.shape[1], len(self.classes_))
        optimizer = torch.optim.Adam(
            self.network_.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay
        )
        loss_function = nn.CrossEntropyLoss()
        generator = torch.Generator().manual_seed(self.random_state)

        best_loss, best_state, epochs_without_improvement = np.inf, None, 0
        self.history_ = {"train_loss": [], "val_loss": [], "val_accuracy": []}

        for _ in range(self.max_epochs):
            # ---- train one epoch (mini-batches) ----
            self.network_.train()
            order = torch.randperm(len(X_train), generator=generator)
            epoch_loss = 0.0
            for start in range(0, len(order), self.batch_size):
                batch = order[start:start + self.batch_size]
                if len(batch) < 2:      # BatchNorm needs at least 2 samples
                    continue
                optimizer.zero_grad()
                loss = loss_function(self.network_(X_train[batch]), y_train[batch])
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item() * len(batch)

            # ---- check on validation data ----
            self.network_.eval()
            with torch.no_grad():
                val_logits = self.network_(X_val)
                val_loss = loss_function(val_logits, y_val).item()
                val_accuracy = (val_logits.argmax(dim=1) == y_val).float().mean().item()

            self.history_["train_loss"].append(epoch_loss / len(X_train))
            self.history_["val_loss"].append(val_loss)
            self.history_["val_accuracy"].append(val_accuracy)

            # ---- early stopping ----
            if val_loss < best_loss - 1e-4:
                best_loss = val_loss
                best_state = copy.deepcopy(self.network_.state_dict())
                epochs_without_improvement = 0
            else:
                epochs_without_improvement += 1
                if epochs_without_improvement >= self.patience:
                    break

        self.network_.load_state_dict(best_state)
        self.network_.eval()
        self.n_epochs_ = len(self.history_["train_loss"])
        return self

    def predict_proba(self, X):
        X = torch.from_numpy(np.asarray(X, dtype=np.float32))
        self.network_.eval()
        with torch.no_grad():
            return torch.softmax(self.network_(X), dim=1).numpy()

    def predict(self, X):
        return self.classes_[self.predict_proba(X).argmax(axis=1)]
