import json
from dataclasses import dataclass
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from xgboost import XGBClassifier

from src.components.deep_learning import DeepNeuralNetworkClassifier
from src.components.feature_engineering import build_preprocessor
from src.config import (
    BINARY_FEATURES,
    CLASS_INFO,
    CLASS_NAMES,
    CONFIDENCE_THRESHOLD,
    CV_FOLDS,
    FEATURE_LABELS,
    FORM_SECTIONS,
    MODEL_DIR,
    MODEL_FILE,
    MODEL_INFO_FILE,
    NORMAL_RANGES,
    NUMERIC_FEATURES,
    RANDOM_STATE,
    REPORTS_DIR,
)
from src.exception import AGDPMException
from src.logger import logger


@dataclass
class ModelTrainerArtifact:
    model: Pipeline
    model_name: str
    cv_results: pd.DataFrame
    model_path: str


def encode_target(y: pd.Series) -> np.ndarray:
    """Class name -> index in CLASS_NAMES (fixed order, no encoder file needed)."""
    return y.map({name: index for index, name in enumerate(CLASS_NAMES)}).to_numpy()


class ModelTrainer:

    def __init__(self):
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)

        # Classes are balanced (~200 each), so no class weights are needed
        self.models = {
            "Logistic Regression": LogisticRegression(max_iter=3000),
            "Support Vector Machine": SVC(probability=True, random_state=RANDOM_STATE),
            "Random Forest": RandomForestClassifier(
                n_estimators=400, random_state=RANDOM_STATE, n_jobs=1
            ),
            "Hist Gradient Boosting": HistGradientBoostingClassifier(
                max_iter=300, learning_rate=0.05, random_state=RANDOM_STATE
            ),
            "XGBoost": XGBClassifier(
                n_estimators=400,
                max_depth=4,
                learning_rate=0.05,
                subsample=0.8,
                colsample_bytree=0.8,
                eval_metric="mlogloss",
                random_state=RANDOM_STATE,
                n_jobs=1,
            ),
            # Deep learning model (PyTorch neural network, see deep_learning.py)
            "Deep Neural Network": DeepNeuralNetworkClassifier(random_state=RANDOM_STATE),
        }

        self.cv = StratifiedKFold(
            n_splits=CV_FOLDS,
            shuffle=True,
            random_state=RANDOM_STATE,
        )

    @staticmethod
    def build_pipeline(model) -> Pipeline:
        return Pipeline(steps=[
            ("preprocessing", build_preprocessor()),
            ("model", model),
        ])

    def build_model_info(self, X_train: pd.DataFrame, model_name: str) -> dict:
        """Everything the UI needs to build the patient form."""
        fields = {}

        for column in NUMERIC_FEATURES:
            values = X_train[column].dropna()
            is_integer = bool((values % 1 == 0).all())
            fields[column] = {
                "type": "number",
                "label": FEATURE_LABELS[column],
                "min": round(float(values.min()), 2),
                "max": round(float(values.max()), 2),
                "step": 1 if is_integer else 0.01,
                "hint": NORMAL_RANGES.get(column, ""),
            }

        for column, choices in BINARY_FEATURES.items():
            fields[column] = {
                "type": "binary",
                "label": FEATURE_LABELS[column],
                "options": [{"value": index, "label": name} for index, name in enumerate(choices)],
            }

        return {
            "model_name": model_name,
            "trained_at": datetime.now().isoformat(timespec="seconds"),
            "classes": CLASS_NAMES,
            "class_info": CLASS_INFO,
            "confidence_threshold": CONFIDENCE_THRESHOLD,
            "sections": FORM_SECTIONS,
            "fields": fields,
        }

    def initiate_model_training(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series
    ) -> ModelTrainerArtifact:

        logger.info("========== MODEL TRAINING STARTED ==========")

        try:
            y_encoded = encode_target(y_train)
            results = []

            for model_name, model in self.models.items():

                logger.info(f"Cross-validating: {model_name}")
                print(f"  Cross-validating {model_name} ...")

                cv_results = cross_validate(
                    self.build_pipeline(model),
                    X_train,
                    y_encoded,
                    cv=self.cv,
                    scoring={"accuracy": "accuracy", "macro_f1": "f1_macro", "log_loss": "neg_log_loss"},
                    return_train_score=True,
                    n_jobs=-1,
                )

                row = {
                    "Model": model_name,
                    "Train Accuracy": cv_results["train_accuracy"].mean(),
                    "CV Accuracy": cv_results["test_accuracy"].mean(),
                    "CV Accuracy Std": cv_results["test_accuracy"].std(),
                    "CV Macro F1": cv_results["test_macro_f1"].mean(),
                    "CV Log Loss": -cv_results["test_log_loss"].mean(),
                }
                results.append(row)

                logger.info(
                    f"{model_name} - train acc {row['Train Accuracy']:.4f}, "
                    f"CV acc {row['CV Accuracy']:.4f}, CV macro F1 {row['CV Macro F1']:.4f}, "
                    f"CV log loss {row['CV Log Loss']:.4f}"
                )

            # Pick the model with the most reliable probabilities (lowest log loss).
            # The app shows a confidence % for every prediction, so the
            # probabilities must be trustworthy, not just the top class.
            results_df = (
                pd.DataFrame(results)
                .sort_values(by=["CV Log Loss", "CV Accuracy"], ascending=[True, False])
                .reset_index(drop=True)
            )
            results_df.to_csv(REPORTS_DIR / "model_comparison.csv", index=False)

            best_model_name = results_df.loc[0, "Model"]
            logger.info(f"Best model by CV log loss: {best_model_name}")

            # Fit the chosen model on the full training split.
            # The holdout set stays untouched for the final evaluation.
            final_pipeline = self.build_pipeline(self.models[best_model_name])
            final_pipeline.fit(X_train, y_encoded)

            joblib.dump(final_pipeline, MODEL_FILE)
            logger.info(f"Model saved: {MODEL_FILE}")

            with open(MODEL_INFO_FILE, "w", encoding="utf-8") as file:
                json.dump(self.build_model_info(X_train, best_model_name), file, indent=2, ensure_ascii=False)
            logger.info(f"Model info saved: {MODEL_INFO_FILE}")

            logger.info("========== MODEL TRAINING COMPLETED ==========")

            return ModelTrainerArtifact(
                model=final_pipeline,
                model_name=best_model_name,
                cv_results=results_df,
                model_path=str(MODEL_FILE),
            )

        except Exception as e:
            logger.exception("Error occurred during model training.")
            raise AGDPMException(e, None) from e
