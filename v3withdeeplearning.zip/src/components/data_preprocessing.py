from dataclasses import dataclass

import pandas as pd
from sklearn.model_selection import train_test_split

from src.config import (
    BINARY_FEATURES,
    CLASS_NAMES,
    HOLDOUT_SIZE,
    INPUT_FEATURES,
    NUMERIC_FEATURES,
    PROCESSED_DATA_DIR,
    RANDOM_STATE,
    TARGET_COLUMN,
)
from src.exception import AGDPMException
from src.logger import logger


def clean_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Turn raw patient records into clean model inputs.
    Used for training AND for prediction, so both always match.

    - keeps only the input features (missing columns are added as empty)
    - binary columns accept 0/1 or their names (e.g. "Female", "Yes")
    - everything becomes numeric; bad values become NaN (imputed later)
    - lab values cannot be negative: the synthetic data has a few small
      negative values (noise), these are clipped to 0
    """
    df = df.reindex(columns=INPUT_FEATURES).copy()

    for column, choices in BINARY_FEATURES.items():
        names = {name.lower(): index for index, name in enumerate(choices)}
        df[column] = df[column].map(
            lambda value: names.get(value.strip().lower(), value) if isinstance(value, str) else value
        )

    for column in INPUT_FEATURES:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    df[NUMERIC_FEATURES] = df[NUMERIC_FEATURES].clip(lower=0)

    return df


@dataclass
class DataPreprocessingArtifact:
    X_train: pd.DataFrame
    X_holdout: pd.DataFrame
    y_train: pd.Series
    y_holdout: pd.Series


class DataPreprocessing:

    def initiate_data_preprocessing(self, df: pd.DataFrame) -> DataPreprocessingArtifact:

        logger.info("========== DATA PREPROCESSING STARTED ==========")

        try:
            PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
            df = df.copy()

            df = df.dropna(how="all")
            df = df.dropna(subset=[TARGET_COLUMN])
            before = len(df)
            df = df.drop_duplicates()
            logger.info(f"Removed {before - len(df)} duplicate rows. Rows left: {len(df)}")

            # Numeric label -> disease name (order documented by the dataset author)
            y = df[TARGET_COLUMN].astype(int).map(dict(enumerate(CLASS_NAMES)))
            if y.isna().any():
                raise ValueError("Found target labels outside 0..4.")

            X = clean_features(df)
            logger.info(f"Class distribution:\n{y.value_counts().to_string()}")

            # Hold back data the model never sees during training
            X_train, X_holdout, y_train, y_holdout = train_test_split(
                X,
                y,
                test_size=HOLDOUT_SIZE,
                stratify=y,
                random_state=RANDOM_STATE,
            )

            X_train.to_csv(PROCESSED_DATA_DIR / "X_train_clean.csv", index=False)
            y_train.to_csv(PROCESSED_DATA_DIR / "y_train.csv", index=False)
            X_holdout.to_csv(PROCESSED_DATA_DIR / "X_holdout_clean.csv", index=False)
            y_holdout.to_csv(PROCESSED_DATA_DIR / "y_holdout.csv", index=False)

            # Holdout patients with their true disease, handy for checking the Batch page
            X_holdout.assign(**{"Actual Disease": y_holdout.values}).to_csv(
                PROCESSED_DATA_DIR / "holdout_patients_with_answers.csv", index=False
            )

            logger.info(f"X_train: {X_train.shape}, X_holdout: {X_holdout.shape}")
            logger.info("========== DATA PREPROCESSING COMPLETED ==========")

            return DataPreprocessingArtifact(
                X_train=X_train.reset_index(drop=True),
                X_holdout=X_holdout.reset_index(drop=True),
                y_train=y_train.reset_index(drop=True),
                y_holdout=y_holdout.reset_index(drop=True),
            )

        except Exception as e:
            logger.exception("Error occurred during data preprocessing.")
            raise AGDPMException(e, None) from e
