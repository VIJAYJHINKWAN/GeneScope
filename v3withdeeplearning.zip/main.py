from src.components.data_ingestion import DataIngestion
from src.components.data_validation import DataValidation
from src.components.data_preprocessing import DataPreprocessing
from src.components.model_trainer import ModelTrainer
from src.components.model_evaluation import ModelEvaluation


def print_summary(model_name, cv_results, metrics):
    print("\n" + "=" * 64)
    print("MODEL COMPARISON (5-fold CV on training split, best = lowest log loss)")
    print("=" * 64)
    print(cv_results.to_string(index=False, float_format=lambda v: f"{v:.4f}"))

    print("\n" + "=" * 64)
    print(f"FINAL RESULTS ON HOLDOUT SET ({metrics['holdout_size']} unseen patients)")
    print("=" * 64)
    print(f"Best model           : {model_name}")
    print(f"Baseline (guessing)  : {metrics['baseline_accuracy']:.2%}")
    print(f"Accuracy             : {metrics['accuracy']:.2%}")
    print(f"Macro F1             : {metrics['macro_f1']:.4f}")
    print(f"Top-2 accuracy       : {metrics['top2_accuracy']:.2%}")
    print(f"AUC (macro)          : {metrics['auc_macro']:.4f}")

    print("\nConfidence-based accuracy:")
    for row in metrics["confidence_table"]:
        accuracy = f"{row['accuracy']:.2%}" if row["accuracy"] is not None else "n/a"
        print(f"  confidence >= {row['threshold']:.0%}: accuracy {accuracy} "
              f"on {row['coverage']:.0%} of patients")

    print("\nPer-class precision / recall / F1:")
    for name, scores in metrics["per_class"].items():
        print(f"  {name:<28} {scores['precision']:.2%}  {scores['recall']:.2%}  {scores['f1']:.3f}")


if __name__ == "__main__":

    print("1/5 Data ingestion ...")
    data = DataIngestion().initiate_data_ingestion().data

    print("2/5 Data validation ...")
    DataValidation().initiate_data_validation(data)

    print("3/5 Data preprocessing ...")
    splits = DataPreprocessing().initiate_data_preprocessing(data)

    print("4/5 Model training ...")
    trainer_artifact = ModelTrainer().initiate_model_training(
        splits.X_train,
        splits.y_train,
    )

    print("5/5 Model evaluation ...")
    evaluation_artifact = ModelEvaluation().initiate_model_evaluation(
        trainer_artifact.model,
        trainer_artifact.model_name,
        trainer_artifact.cv_results,
        splits.X_holdout,
        splits.y_holdout,
    )

    print_summary(
        trainer_artifact.model_name,
        trainer_artifact.cv_results,
        evaluation_artifact.metrics,
    )
    print("\nDone. Start the app with:  uvicorn app.main:app --reload")
