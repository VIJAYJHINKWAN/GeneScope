import pandas as pd

from src.components.data_ingestion import DataIngestion
from src.components.data_validation import DataValidation
from src.components.data_preprocessing import DataPreprocessing
from src.components.model_trainer import ModelTrainer
from src.components.model_evaluation import ModelEvaluation
from src.config import PREDICTIONS_DIR
from src.pipeline.predict_pipeline import PredictPipeline


def print_summary(model_name, cv_results, metrics):
    print("\n" + "=" * 64)
    print("MODEL COMPARISON (5-fold CV on training split, best = lowest log loss)")
    print("=" * 64)
    print(cv_results.to_string(index=False, float_format=lambda v: f"{v:.4f}"))

    print("\n" + "=" * 64)
    print(f"FINAL RESULTS ON HOLDOUT SET ({metrics['holdout_size']} unseen patients)")
    print("=" * 64)
    print(f"Best model           : {model_name}")
    print(f"Baseline (guessing)  : {metrics['baseline_accuracy']:.2%}")
    print(f"Accuracy             : {metrics['accuracy']:.2%}")
    print(f"Macro F1             : {metrics['macro_f1']:.4f}")
    print(f"Top-2 accuracy       : {metrics['top2_accuracy']:.2%}")
    print(f"AUC (macro)          : {metrics['auc_macro']:.4f}")

    print("\nConfidence-based accuracy:")
    for row in metrics["confidence_table"]:
        accuracy = f"{row['accuracy']:.2%}" if row["accuracy"] is not None else "n/a"
        print(f"  confidence >= {row['threshold']:.0%}: accuracy {accuracy} "
              f"on {row['coverage']:.0%} of patients")

    print("\nPer-class recall:")
    for name, scores in metrics["per_class"].items():
        print(f"  {name:<46} {scores['recall']:.2%}")


if __name__ == "__main__":

    print("1/6 Data ingestion ...")
    ingestion_artifact = DataIngestion().initiate_data_ingestion()

    print("2/6 Data validation ...")
    DataValidation().initiate_data_validation(
        ingestion_artifact.train_data,
        ingestion_artifact.test_data,
    )

    print("3/6 Data preprocessing ...")
    data = DataPreprocessing().initiate_data_preprocessing(
        ingestion_artifact.train_data,
        ingestion_artifact.test_data,
    )

    print("4/6 Model training ...")
    trainer_artifact = ModelTrainer().initiate_model_training(
        data.X_train,
        data.y_train,
    )

    print("5/6 Model evaluation ...")
    evaluation_artifact = ModelEvaluation().initiate_model_evaluation(
        trainer_artifact.model,
        trainer_artifact.model_name,
        trainer_artifact.cv_results,
        data.X_holdout,
        data.y_holdout,
    )

    print("6/6 Predicting the unlabelled test file ...")
    PREDICTIONS_DIR.mkdir(parents=True, exist_ok=True)
    predictions = PredictPipeline().predict_dataframe(data.X_test)
    predictions_df = pd.DataFrame({
        "Patient Id": data.test_ids,
        "Predicted Genetic Disorder": [p["prediction"] for p in predictions],
        "Confidence": [p["confidence"] for p in predictions],
        "Confidence Level": [p["confidence_level"] for p in predictions],
    })
    predictions_path = PREDICTIONS_DIR / "test_predictions.csv"
    predictions_df.to_csv(predictions_path, index=False)

    print_summary(
        trainer_artifact.model_name,
        trainer_artifact.cv_results,
        evaluation_artifact.metrics,
    )
    print(f"\nTest predictions saved: {predictions_path}")
    print("Done. Start the app with:  uvicorn app.main:app --reload")
