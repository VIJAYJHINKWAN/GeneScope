# GeneScope, Version 2: Genetic Disorder Predictor

Version 2 adds **Disorder Subclass** as a model input together with the
patient's symptoms, genetics, clinical signs and blood tests.
Accuracy on 4,149 unseen patients is about 96%.

Predicts which genetic inheritance category a patient most likely belongs to
(Mitochondrial, Multifactorial or Single-gene) from the *Predict the Genetic
Disorders* dataset, with a web UI for single-patient and CSV batch predictions.

## Run

```
venv\Scripts\activate
pip install -r requirements.txt
python main.py                      # clean data, train, evaluate (~2 min)
uvicorn app.main:app --reload       # start the app
```

Open http://127.0.0.1:8000

## Project structure

```
data/raw/            original dataset (never modified)
data/working/        copy of the dataset used by the pipeline
data/processed/      cleaned train / holdout / test splits
src/config.py        paths, feature lists, settings
src/components/      ingestion → validation → preprocessing → features → training → evaluation
src/pipeline/        prediction (used by main.py and the API)
app/main.py          FastAPI backend
app/static/          frontend (HTML, CSS, JS)
artifacts/models/    trained model + model info for the UI
artifacts/reports/   metrics, confusion matrix, model comparison, feature importance
artifacts/predictions/  predictions for the unlabelled test file
```

## Pipeline

1. **Ingestion**: copy `data/raw` → `data/working` and read the copy.
2. **Validation**: data-quality report in `artifacts/validation/`.
3. **Preprocessing**: remove empty and duplicate rows, recover missing labels
   from *Disorder Subclass* (used only for labels, never as an input),
   unify "unknown" values, then a stratified 80/20 train/holdout split.
4. **Features**: symptom total and inherited-gene count. Imputation with
   missing-value flags and one-hot encoding, all inside the saved pipeline.
5. **Training**: 5 models compared with 5-fold CV. The one with the lowest
   log loss (most reliable probabilities) is kept.
6. **Evaluation**: on the 20% holdout only. Accuracy, macro F1, top-2 accuracy,
   AUC, accuracy by confidence level, confusion matrix and feature importance.

## API

| Method | Path | Purpose |
|---|---|---|
| GET  | `/api/health` | status |
| GET  | `/api/model-info` | form fields and options |
| GET  | `/api/metrics` | evaluation results |
| GET  | `/api/sample` | random holdout patient (for demos) |
| POST | `/api/predict` | predict one patient (JSON) |
| POST | `/api/predict-batch` | predict a CSV file |

Interactive docs: http://127.0.0.1:8000/docs

> Educational project. Not for clinical use.
