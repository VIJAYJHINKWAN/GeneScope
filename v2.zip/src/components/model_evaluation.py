import json
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    roc_auc_score,
)
from sklearn.pipeline import Pipeline

from src.components.model_trainer import encode_target
from src.config import (
    CLASS_NAMES,
    CONFIDENCE_THRESHOLD,
    CONFIDENCE_THRESHOLDS_TO_REPORT,
    FEATURE_LABELS,
    METRICS_FILE,
    RANDOM_STATE,
    REPORTS_DIR,
)
from src.exception import AGDPMException
from src.logger import logger


@dataclass
class ModelEvaluationArtifact:
    metrics: dict
    metrics_path: str


class ModelEvaluation:
    """
    Final, honest evaluation on the holdout set
    (20% of labelled data the model never saw during training).
    """

    def initiate_model_evaluation(
        self,
        model: Pipeline,
        model_name: str,
        cv_results: pd.DataFrame,
        X_holdout: pd.DataFrame,
        y_holdout: pd.Series,
    ) -> ModelEvaluationArtifact:

        logger.info("========== MODEL EVALUATION STARTED ==========")

        try:
            REPORTS_DIR.mkdir(parents=True, exist_ok=True)

            y_true = encode_target(y_holdout)
            probabilities = model.predict_proba(X_holdout)
            y_pred = probabilities.argmax(axis=1)
            confidence = probabilities.max(axis=1)

            # Baseline: always predict the most common class
            baseline_accuracy = float(np.bincount(y_true).max() / len(y_true))

            # Top-2: is the true class among the two most likely?
            top2 = np.argsort(-probabilities, axis=1)[:, :2]
            top2_accuracy = float((top2 == y_true[:, None]).any(axis=1).mean())

            auc_per_class = roc_auc_score(
                y_true, probabilities, multi_class="ovr", average=None
            )

            # Accuracy when we only trust confident predictions
            confidence_table = []
            for threshold in CONFIDENCE_THRESHOLDS_TO_REPORT:
                selected = confidence >= threshold
                confidence_table.append({
                    "threshold": threshold,
                    "coverage": float(selected.mean()),
                    "accuracy": float((y_pred[selected] == y_true[selected]).mean())
                    if selected.any() else None,
                    "patients": int(selected.sum()),
                })

            report = classification_report(
                y_true,
                y_pred,
                labels=list(range(len(CLASS_NAMES))),
                target_names=CLASS_NAMES,
                output_dict=True,
                zero_division=0,
            )
            matrix = confusion_matrix(y_true, y_pred, labels=list(range(len(CLASS_NAMES))))

            # Which inputs matter most (measured on unseen data)
            importance = permutation_importance(
                model,
                X_holdout,
                y_true,
                scoring="accuracy",
                n_repeats=5,
                random_state=RANDOM_STATE,
                n_jobs=-1,
            )
            feature_importance = (
                pd.DataFrame({
                    "feature": X_holdout.columns,
                    "label": [FEATURE_LABELS.get(c, c) for c in X_holdout.columns],
                    "importance": importance.importances_mean,
                })
                .sort_values("importance", ascending=False)
                .reset_index(drop=True)
            )

            metrics = {
                "model_name": model_name,
                "holdout_size": int(len(y_true)),
                "accuracy": float(accuracy_score(y_true, y_pred)),
                "macro_f1": float(f1_score(y_true, y_pred, average="macro")),
                "weighted_f1": float(f1_score(y_true, y_pred, average="weighted")),
                "baseline_accuracy": baseline_accuracy,
                "top2_accuracy": top2_accuracy,
                "auc_macro": float(np.mean(auc_per_class)),
                "auc_per_class": dict(zip(CLASS_NAMES, map(float, auc_per_class))),
                "confidence_threshold": CONFIDENCE_THRESHOLD,
                "confidence_table": confidence_table,
                "per_class": {
                    name: {
                        "precision": report[name]["precision"],
                        "recall": report[name]["recall"],
                        "f1": report[name]["f1-score"],
                        "support": int(report[name]["support"]),
                    }
                    for name in CLASS_NAMES
                },
                "confusion_matrix": matrix.tolist(),
                "classes": CLASS_NAMES,
                "model_comparison": cv_results.to_dict(orient="records"),
                "feature_importance": feature_importance.head(15).to_dict(orient="records"),
            }

            with open(METRICS_FILE, "w", encoding="utf-8") as file:
                json.dump(metrics, file, indent=2)

            pd.DataFrame(report).transpose().to_csv(REPORTS_DIR / "classification_report.csv")
            pd.DataFrame(matrix, index=CLASS_NAMES, columns=CLASS_NAMES).to_csv(
                REPORTS_DIR / "confusion_matrix.csv"
            )
            pd.DataFrame(confidence_table).to_csv(REPORTS_DIR / "confidence_table.csv", index=False)
            feature_importance.to_csv(REPORTS_DIR / "feature_importance.csv", index=False)

            logger.info(f"Holdout metrics: accuracy {metrics['accuracy']:.4f}, "
                        f"macro F1 {metrics['macro_f1']:.4f}, top-2 {top2_accuracy:.4f}")
            logger.info(f"Metrics saved: {METRICS_FILE}")
            logger.info("========== MODEL EVALUATION COMPLETED ==========")

            return ModelEvaluationArtifact(metrics=metrics, metrics_path=str(METRICS_FILE))

        except Exception as e:
            logger.exception("Error occurred during model evaluation.")
            raise AGDPMException(e, None) from e
