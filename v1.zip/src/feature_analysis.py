import pandas as pd
from sklearn.feature_selection import mutual_info_classif
from sklearn.preprocessing import LabelEncoder


# ---------------------------------------
# Load processed training data
# ---------------------------------------

X_train = pd.read_csv(
    "data/processed/X_train_clean.csv"
)

y_train = pd.read_csv(
    "data/processed/y_train.csv"
).squeeze()


# ---------------------------------------
# Encode target
# ---------------------------------------

label_encoder = LabelEncoder()

y_encoded = label_encoder.fit_transform(y_train)


# ---------------------------------------
# Convert features
# ---------------------------------------

X_encoded = X_train.copy()

discrete_features = []

for column in X_encoded.columns:

    if X_encoded[column].dtype == "object":

        X_encoded[column] = (
            X_encoded[column]
            .astype("category")
            .cat.codes
        )

        discrete_features.append(True)

    else:

        X_encoded[column] = pd.to_numeric(
            X_encoded[column],
            errors="coerce"
        )

        discrete_features.append(False)


# ---------------------------------------
# Handle missing values
# ---------------------------------------

for column in X_encoded.columns:

    if X_encoded[column].isna().any():

        if X_encoded[column].dtype == "object":

            X_encoded[column] = X_encoded[column].fillna(
                "Missing"
            )

        else:

            X_encoded[column] = X_encoded[column].fillna(
                X_encoded[column].median()
            )


# ---------------------------------------
# Make sure everything is numeric
# ---------------------------------------

X_encoded = X_encoded.apply(
    pd.to_numeric,
    errors="coerce"
)

X_encoded = X_encoded.fillna(0)


# ---------------------------------------
# Calculate Mutual Information
# ---------------------------------------

mi_scores = mutual_info_classif(
    X_encoded,
    y_encoded,
    discrete_features=discrete_features,
    random_state=42
)


# ---------------------------------------
# Create feature importance table
# ---------------------------------------

feature_importance = pd.DataFrame(
    {
        "Feature": X_encoded.columns,
        "Mutual Information": mi_scores
    }
)

feature_importance = feature_importance.sort_values(
    by="Mutual Information",
    ascending=False
).reset_index(drop=True)


# ---------------------------------------
# Display results
# ---------------------------------------

print("\n" + "=" * 70)
print("AGDPM FEATURE USEFULNESS ANALYSIS")
print("=" * 70)

print(
    feature_importance.to_string(index=False)
)


# ---------------------------------------
# Save results
# ---------------------------------------

feature_importance.to_csv(
    "artifacts/feature_importance_mutual_information.csv",
    index=False
)

print("\nResults saved to:")
print(
    "artifacts/feature_importance_mutual_information.csv"
)