from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------
# Paths
# ---------------------------------------------------------

DATA_DIR = PROJECT_ROOT / "data"
RAW_DATA_DIR = DATA_DIR / "raw"            # original files, never modified
WORKING_DATA_DIR = DATA_DIR / "working"    # copy used by the pipeline
PROCESSED_DATA_DIR = DATA_DIR / "processed"

RAW_TRAIN_FILE = RAW_DATA_DIR / "train_genetic_disorders.csv"
RAW_TEST_FILE = RAW_DATA_DIR / "test_genetic_disorders.csv"

TRAIN_DATA_FILE = WORKING_DATA_DIR / "train_genetic_disorders.csv"
TEST_DATA_FILE = WORKING_DATA_DIR / "test_genetic_disorders.csv"

ARTIFACTS_DIR = PROJECT_ROOT / "artifacts"
VALIDATION_DIR = ARTIFACTS_DIR / "validation"
MODEL_DIR = ARTIFACTS_DIR / "models"
REPORTS_DIR = ARTIFACTS_DIR / "reports"
PREDICTIONS_DIR = ARTIFACTS_DIR / "predictions"

MODEL_FILE = MODEL_DIR / "model_pipeline.pkl"
MODEL_INFO_FILE = MODEL_DIR / "model_info.json"
METRICS_FILE = REPORTS_DIR / "metrics.json"

LOG_DIR = PROJECT_ROOT / "logs"

# ---------------------------------------------------------
# Target
# ---------------------------------------------------------

TARGET_COLUMN = "Genetic Disorder"
SUBCLASS_COLUMN = "Disorder Subclass"
ID_COLUMN = "Patient Id"

CLASS_NAMES = [
    "Mitochondrial genetic inheritance disorders",
    "Multifactorial genetic inheritance disorders",
    "Single-gene inheritance diseases",
]

# Every subclass belongs to exactly one disorder. Used ONLY to recover
# missing labels in training data, never as a model input.
SUBCLASS_TO_DISORDER = {
    "Leber's hereditary optic neuropathy": CLASS_NAMES[0],
    "Leigh syndrome": CLASS_NAMES[0],
    "Mitochondrial myopathy": CLASS_NAMES[0],
    "Alzheimer's": CLASS_NAMES[1],
    "Cancer": CLASS_NAMES[1],
    "Diabetes": CLASS_NAMES[1],
    "Cystic fibrosis": CLASS_NAMES[2],
    "Hemochromatosis": CLASS_NAMES[2],
    "Tay-Sachs": CLASS_NAMES[2],
}

# ---------------------------------------------------------
# Features (exactly what a patient enters in the UI)
# ---------------------------------------------------------

NUMERIC_FEATURES = [
    "Patient Age",
    "Mother's age",
    "Father's age",
    "No. of previous abortion",
    "Blood cell count (mcL)",
    "White Blood cell count (thousand per microliter)",
]

SYMPTOM_FEATURES = [
    "Symptom 1",
    "Symptom 2",
    "Symptom 3",
    "Symptom 4",
    "Symptom 5",
]

GENE_FEATURES = [
    "Genes in mother's side",
    "Inherited from father",
    "Maternal gene",
    "Paternal gene",
]

CATEGORICAL_FEATURES = GENE_FEATURES + [
    "Gender",
    "Status",
    "Place of birth",
    "Follow-up",
    "Respiratory Rate (breaths/min)",
    "Heart Rate (rates/min",
    "Birth asphyxia",
    "Autopsy shows birth defect (if applicable)",
    "Birth defects",
    "Folic acid details (peri-conceptional)",
    "H/O serious maternal illness",
    "H/O radiation exposure (x-ray)",
    "H/O substance abuse",
    "Assisted conception IVF/ART",
    "History of anomalies in previous pregnancies",
    "Blood test result",
]

INPUT_FEATURES = NUMERIC_FEATURES + SYMPTOM_FEATURES + CATEGORICAL_FEATURES

# Created by feature engineering
ENGINEERED_NUMERIC_FEATURES = [
    "Symptom Total",
    "Inherited Gene Count",
]

# Different spellings of "we don't know" in the raw data
UNKNOWN_VALUE = "Unknown"
UNKNOWN_ALIASES = ["-", "Not applicable", "No record", "Not available", ""]

# ---------------------------------------------------------
# Training settings
# ---------------------------------------------------------

RANDOM_STATE = 42
HOLDOUT_SIZE = 0.20
CV_FOLDS = 5

# Predictions at or above this probability are shown as "confident"
CONFIDENCE_THRESHOLD = 0.70
CONFIDENCE_THRESHOLDS_TO_REPORT = [0.50, 0.60, 0.65, 0.70]

# ---------------------------------------------------------
# UI: friendly labels and form sections
# ---------------------------------------------------------

FEATURE_LABELS = {
    "Patient Age": "Patient age (years)",
    "Mother's age": "Mother's age (years)",
    "Father's age": "Father's age (years)",
    "No. of previous abortion": "Number of previous abortions",
    "Blood cell count (mcL)": "Blood cell count (mcL)",
    "White Blood cell count (thousand per microliter)": "White blood cell count (thousand/µL)",
    "Symptom 1": "Symptom 1",
    "Symptom 2": "Symptom 2",
    "Symptom 3": "Symptom 3",
    "Symptom 4": "Symptom 4",
    "Symptom 5": "Symptom 5",
    "Genes in mother's side": "Defective gene on mother's side",
    "Inherited from father": "Defective gene inherited from father",
    "Maternal gene": "Maternal gene",
    "Paternal gene": "Paternal gene",
    "Gender": "Gender",
    "Status": "Status",
    "Place of birth": "Place of birth",
    "Follow-up": "Follow-up",
    "Respiratory Rate (breaths/min)": "Respiratory rate",
    "Heart Rate (rates/min": "Heart rate",
    "Birth asphyxia": "Birth asphyxia",
    "Autopsy shows birth defect (if applicable)": "Autopsy shows birth defect",
    "Birth defects": "Birth defects",
    "Folic acid details (peri-conceptional)": "Folic acid (peri-conceptional)",
    "H/O serious maternal illness": "History of serious maternal illness",
    "H/O radiation exposure (x-ray)": "History of radiation exposure (x-ray)",
    "H/O substance abuse": "History of substance abuse",
    "Assisted conception IVF/ART": "Assisted conception (IVF/ART)",
    "History of anomalies in previous pregnancies": "Anomalies in previous pregnancies",
    "Blood test result": "Blood test result",
}

FORM_SECTIONS = [
    {
        "title": "Patient Information",
        "fields": ["Patient Age", "Gender", "Status", "Place of birth", "Follow-up"],
    },
    {
        "title": "Genetics & Family",
        "fields": GENE_FEATURES + ["Mother's age", "Father's age"],
    },
    {
        "title": "Symptoms",
        "fields": SYMPTOM_FEATURES,
    },
    {
        "title": "Clinical Signs",
        "fields": [
            "Respiratory Rate (breaths/min)",
            "Heart Rate (rates/min",
            "Birth asphyxia",
            "Birth defects",
            "Autopsy shows birth defect (if applicable)",
        ],
    },
    {
        "title": "Pregnancy History",
        "fields": [
            "Folic acid details (peri-conceptional)",
            "H/O serious maternal illness",
            "H/O radiation exposure (x-ray)",
            "H/O substance abuse",
            "Assisted conception IVF/ART",
            "History of anomalies in previous pregnancies",
            "No. of previous abortion",
        ],
    },
    {
        "title": "Blood Tests",
        "fields": [
            "Blood cell count (mcL)",
            "White Blood cell count (thousand per microliter)",
            "Blood test result",
        ],
    },
]
