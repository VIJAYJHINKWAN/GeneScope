import json
from dataclasses import dataclass
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.utils.class_weight import compute_sample_weight
from xgboost import XGBClassifier

from src.components.feature_engineering import build_preprocessor
from src.config import (
    CATEGORICAL_FEATURES,
    CLASS_NAMES,
    CONFIDENCE_THRESHOLD,
    CV_FOLDS,
    FEATURE_LABELS,
    FORM_SECTIONS,
    MODEL_DIR,
    MODEL_FILE,
    MODEL_INFO_FILE,
    NUMERIC_FEATURES,
    RANDOM_STATE,
    REPORTS_DIR,
    SYMPTOM_FEATURES,
    UNKNOWN_VALUE,
)
from src.exception import AGDPMException
from src.logger import logger


@dataclass
class ModelTrainerArtifact:
    model: Pipeline
    model_name: str
    cv_results: pd.DataFrame
    model_path: str


def encode_target(y: pd.Series) -> np.ndarray:
    """Class name -> index in CLASS_NAMES (fixed order, no encoder file needed)."""
    return y.map({name: index for index, name in enumerate(CLASS_NAMES)}).to_numpy()


class ModelTrainer:

    def __init__(self):
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)

        # (model, uses_balanced_sample_weights)
        self.models = {
            "Logistic Regression": (
                LogisticRegression(max_iter=2000, class_weight="balanced"),
                False,
            ),
            "Random Forest": (
                RandomForestClassifier(
                    n_estimators=400,
                    min_samples_leaf=5,
                    class_weight="balanced_subsample",
                    random_state=RANDOM_STATE,
                    n_jobs=1,
                ),
                False,
            ),
            "Hist Gradient Boosting": (
                HistGradientBoostingClassifier(
                    max_iter=300,
                    learning_rate=0.03,
                    max_depth=4,
                    random_state=RANDOM_STATE,
                ),
                False,
            ),
            "XGBoost": (
                XGBClassifier(
                    n_estimators=800,
                    max_depth=4,
                    learning_rate=0.02,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    min_child_weight=5,
                    eval_metric="mlogloss",
                    random_state=RANDOM_STATE,
                    n_jobs=1,
                ),
                False,
            ),
            "XGBoost (balanced)": (
                XGBClassifier(
                    n_estimators=800,
                    max_depth=4,
                    learning_rate=0.02,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    min_child_weight=5,
                    eval_metric="mlogloss",
                    random_state=RANDOM_STATE,
                    n_jobs=1,
                ),
                True,
            ),
        }

        self.cv = StratifiedKFold(
            n_splits=CV_FOLDS,
            shuffle=True,
            random_state=RANDOM_STATE,
        )

    @staticmethod
    def build_pipeline(model) -> Pipeline:
        return Pipeline(steps=[
            ("preprocessing", build_preprocessor()),
            ("model", model),
        ])

    @staticmethod
    def fit_params(y_encoded: np.ndarray, balanced: bool) -> dict:
        if not balanced:
            return {}
        return {"model__sample_weight": compute_sample_weight("balanced", y_encoded)}

    def build_model_info(self, X_train: pd.DataFrame, model_name: str) -> dict:
        """Everything the UI needs to build the patient form."""
        fields = {}

        for column in NUMERIC_FEATURES:
            values = X_train[column].dropna()
            fields[column] = {
                "type": "number",
                "label": FEATURE_LABELS[column],
                "min": float(values.min()),
                "max": float(values.max()),
                "default": round(float(values.median()), 2),
                "step": 1 if (values % 1 == 0).all() else 0.01,
            }

        for column in SYMPTOM_FEATURES:
            fields[column] = {"type": "symptom", "label": FEATURE_LABELS[column]}

        for column in CATEGORICAL_FEATURES:
            options = sorted(set(X_train[column]) - {UNKNOWN_VALUE}) + [UNKNOWN_VALUE]
            fields[column] = {
                "type": "select",
                "label": FEATURE_LABELS[column],
                "options": options,
                "default": UNKNOWN_VALUE,
            }

        return {
            "model_name": model_name,
            "trained_at": datetime.now().isoformat(timespec="seconds"),
            "classes": CLASS_NAMES,
            "confidence_threshold": CONFIDENCE_THRESHOLD,
            "sections": FORM_SECTIONS,
            "fields": fields,
        }

    def initiate_model_training(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series
    ) -> ModelTrainerArtifact:

        logger.info("========== MODEL TRAINING STARTED ==========")

        try:
            y_encoded = encode_target(y_train)
            results = []

            for model_name, (model, balanced) in self.models.items():

                logger.info(f"Cross-validating: {model_name}")
                print(f"  Cross-validating {model_name} ...")

                cv_results = cross_validate(
                    self.build_pipeline(model),
                    X_train,
                    y_encoded,
                    cv=self.cv,
                    scoring={"accuracy": "accuracy", "macro_f1": "f1_macro", "log_loss": "neg_log_loss"},
                    return_train_score=True,
                    params=self.fit_params(y_encoded, balanced),
                    n_jobs=-1,
                )

                row = {
                    "Model": model_name,
                    "Train Accuracy": cv_results["train_accuracy"].mean(),
                    "CV Accuracy": cv_results["test_accuracy"].mean(),
                    "CV Accuracy Std": cv_results["test_accuracy"].std(),
                    "CV Macro F1": cv_results["test_macro_f1"].mean(),
                    "CV Log Loss": -cv_results["test_log_loss"].mean(),
                }
                results.append(row)

                logger.info(
                    f"{model_name} - train acc {row['Train Accuracy']:.4f}, "
                    f"CV acc {row['CV Accuracy']:.4f}, CV macro F1 {row['CV Macro F1']:.4f}, "
                    f"CV log loss {row['CV Log Loss']:.4f}"
                )

            # Pick the model with the most reliable probabilities (lowest log loss).
            # The app shows a confidence % for every prediction, so the
            # probabilities must be trustworthy, not just the top class.
            results_df = (
                pd.DataFrame(results)
                .sort_values(by=["CV Log Loss", "CV Accuracy"], ascending=[True, False])
                .reset_index(drop=True)
            )
            results_df.to_csv(REPORTS_DIR / "model_comparison.csv", index=False)

            best_model_name = results_df.loc[0, "Model"]
            best_model, balanced = self.models[best_model_name]
            logger.info(f"Best model by CV log loss: {best_model_name}")

            # Fit the chosen model on the full training split.
            # The holdout set stays untouched for the final evaluation.
            final_pipeline = self.build_pipeline(best_model)
            final_pipeline.fit(X_train, y_encoded, **self.fit_params(y_encoded, balanced))

            joblib.dump(final_pipeline, MODEL_FILE)
            logger.info(f"Model saved: {MODEL_FILE}")

            with open(MODEL_INFO_FILE, "w", encoding="utf-8") as file:
                json.dump(self.build_model_info(X_train, best_model_name), file, indent=2)
            logger.info(f"Model info saved: {MODEL_INFO_FILE}")

            logger.info("========== MODEL TRAINING COMPLETED ==========")

            return ModelTrainerArtifact(
                model=final_pipeline,
                model_name=best_model_name,
                cv_results=results_df,
                model_path=str(MODEL_FILE),
            )

        except Exception as e:
            logger.exception("Error occurred during model training.")
            raise AGDPMException(e, None) from e
