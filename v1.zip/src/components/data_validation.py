from dataclasses import dataclass

import pandas as pd

from src.config import VALIDATION_DIR
from src.exception import AGDPMException
from src.logger import logger


@dataclass
class DataValidationArtifact:
    validation_status: bool
    validation_report_path: str


class DataValidation:

    def __init__(self):
        self.validation_dir = VALIDATION_DIR
        self.validation_dir.mkdir(parents=True, exist_ok=True)

        self.report_path = self.validation_dir / "validation_report.txt"

        self.target_columns = [
            "Genetic Disorder",
            "Disorder Subclass"
        ]

    def initiate_data_validation(
        self,
        train_df: pd.DataFrame,
        test_df: pd.DataFrame
    ) -> DataValidationArtifact:

        logger.info("========== DATA VALIDATION STARTED ==========")

        try:
            validation_errors = []

            # ==================================================
            # Dataset information
            # ==================================================

            logger.info(f"Train dataset shape: {train_df.shape}")
            logger.info(f"Test dataset shape: {test_df.shape}")
            logger.info(f"Train number of columns: {len(train_df.columns)}")
            logger.info(f"Test number of columns: {len(test_df.columns)}")

            # ==================================================
            # Empty dataset validation
            # ==================================================

            if train_df.empty:
                validation_errors.append("Training dataset is empty.")
                logger.error("Training dataset is empty.")
            else:
                logger.info("Training dataset is not empty.")

            if test_df.empty:
                validation_errors.append("Testing dataset is empty.")
                logger.error("Testing dataset is empty.")
            else:
                logger.info("Testing dataset is not empty.")

            # ==================================================
            # Duplicate rows
            # ==================================================

            train_duplicates = int(train_df.duplicated().sum())
            test_duplicates = int(test_df.duplicated().sum())

            logger.info(f"Train duplicate rows: {train_duplicates}")
            logger.info(f"Test duplicate rows: {test_duplicates}")

            if train_duplicates > 0:
                validation_errors.append(
                    f"Train contains {train_duplicates} duplicate rows."
                )

            if test_duplicates > 0:
                validation_errors.append(
                    f"Test contains {test_duplicates} duplicate rows."
                )

            # ==================================================
            # Completely empty rows
            # ==================================================

            train_empty_rows = int(
                train_df.isna().all(axis=1).sum()
            )

            test_empty_rows = int(
                test_df.isna().all(axis=1).sum()
            )

            logger.info(
                f"Train completely empty rows: {train_empty_rows}"
            )

            logger.info(
                f"Test completely empty rows: {test_empty_rows}"
            )

            if train_empty_rows > 0:
                validation_errors.append(
                    f"Train contains {train_empty_rows} completely empty rows."
                )

            if test_empty_rows > 0:
                validation_errors.append(
                    f"Test contains {test_empty_rows} completely empty rows."
                )

            # ==================================================
            # Missing values - complete information
            # ==================================================

            logger.info("---------- MISSING VALUE ANALYSIS ----------")

            train_missing = train_df.isna().sum()
            test_missing = test_df.isna().sum()

            train_total_missing = int(train_missing.sum())
            test_total_missing = int(test_missing.sum())

            logger.info(
                f"Total missing values in train: {train_total_missing}"
            )

            logger.info(
                f"Total missing values in test: {test_total_missing}"
            )

            logger.info("Train missing values by column:")

            for column, count in train_missing.items():

                if count > 0:
                    percentage = (count / len(train_df)) * 100

                    logger.info(
                        f"{column}: {count} missing "
                        f"({percentage:.2f}%)"
                    )

            logger.info("Test missing values by column:")

            for column, count in test_missing.items():

                if count > 0:
                    percentage = (count / len(test_df)) * 100

                    logger.info(
                        f"{column}: {count} missing "
                        f"({percentage:.2f}%)"
                    )

            # ==================================================
            # Target column validation
            # ==================================================

            logger.info("---------- TARGET VALIDATION ----------")

            for column in self.target_columns:

                if column not in train_df.columns:

                    validation_errors.append(
                        f"Missing target column in train: {column}"
                    )

                    logger.error(
                        f"Missing target column in train: {column}"
                    )

                else:

                    missing_target = int(
                        train_df[column].isna().sum()
                    )

                    non_missing_target = int(
                        train_df[column].notna().sum()
                    )

                    unique_target_values = int(
                        train_df[column].nunique(dropna=True)
                    )

                    logger.info(
                        f"Target '{column}' - "
                        f"missing: {missing_target}, "
                        f"non-missing: {non_missing_target}, "
                        f"unique values: {unique_target_values}"
                    )

                    if missing_target > 0:

                        validation_errors.append(
                            f"Target '{column}' contains "
                            f"{missing_target} missing values."
                        )

                if column in test_df.columns:

                    validation_errors.append(
                        f"Target column '{column}' is present in test data."
                    )

                    logger.error(
                        f"Target column '{column}' is incorrectly present in test data."
                    )

                else:

                    logger.info(
                        f"Target '{column}' correctly absent from test data."
                    )

            # ==================================================
            # Train/Test feature comparison
            # ==================================================

            logger.info("---------- FEATURE COLUMN VALIDATION ----------")

            train_features = [
                column
                for column in train_df.columns
                if column not in self.target_columns
            ]

            test_features = list(test_df.columns)

            missing_in_test = sorted(
                set(train_features) - set(test_features)
            )

            extra_in_test = sorted(
                set(test_features) - set(train_features)
            )

            logger.info(
                f"Number of train features: {len(train_features)}"
            )

            logger.info(
                f"Number of test features: {len(test_features)}"
            )

            if missing_in_test:

                validation_errors.append(
                    f"Features missing from test: {missing_in_test}"
                )

                logger.error(
                    f"Features missing from test: {missing_in_test}"
                )

            else:

                logger.info(
                    "All training features are present in test data."
                )

            if extra_in_test:

                validation_errors.append(
                    f"Unexpected features in test: {extra_in_test}"
                )

                logger.error(
                    f"Unexpected features in test: {extra_in_test}"
                )

            else:

                logger.info(
                    "No unexpected features found in test data."
                )

            # ==================================================
            # Data type information
            # ==================================================

            logger.info("---------- DATA TYPE ANALYSIS ----------")

            for column in train_df.columns:

                logger.info(
                    f"Train column '{column}' dtype: "
                    f"{train_df[column].dtype}"
                )

            for column in test_df.columns:

                logger.info(
                    f"Test column '{column}' dtype: "
                    f"{test_df[column].dtype}"
                )

            # ==================================================
            # Final validation status
            # ==================================================

            validation_status = len(validation_errors) == 0

            if validation_status:

                logger.info(
                    "DATA VALIDATION PASSED."
                )

            else:

                logger.warning(
                    f"DATA VALIDATION FOUND {len(validation_errors)} ISSUE(S)."
                )

                for error in validation_errors:
                    logger.warning(f"Validation issue: {error}")

            # ==================================================
            # Save validation report
            # ==================================================

            with open(
                self.report_path,
                "w",
                encoding="utf-8"
            ) as file:

                file.write(
                    "AGDPM DATA VALIDATION REPORT\n"
                )

                file.write(
                    "=" * 70 + "\n\n"
                )

                file.write(
                    f"Validation Status: {validation_status}\n"
                )

                file.write(
                    f"Train Shape: {train_df.shape}\n"
                )

                file.write(
                    f"Test Shape: {test_df.shape}\n\n"
                )

                file.write(
                    f"Train Duplicate Rows: {train_duplicates}\n"
                )

                file.write(
                    f"Test Duplicate Rows: {test_duplicates}\n\n"
                )

                file.write(
                    f"Train Completely Empty Rows: {train_empty_rows}\n"
                )

                file.write(
                    f"Test Completely Empty Rows: {test_empty_rows}\n\n"
                )

                file.write(
                    f"Train Total Missing Values: {train_total_missing}\n"
                )

                file.write(
                    f"Test Total Missing Values: {test_total_missing}\n\n"
                )

                file.write(
                    "TRAIN MISSING VALUES BY COLUMN\n"
                )

                file.write(
                    "-" * 70 + "\n"
                )

                file.write(
                    train_missing.to_string()
                )

                file.write("\n\n")

                file.write(
                    "TEST MISSING VALUES BY COLUMN\n"
                )

                file.write(
                    "-" * 70 + "\n"
                )

                file.write(
                    test_missing.to_string()
                )

                file.write("\n\n")

                file.write(
                    "VALIDATION ISSUES\n"
                )

                file.write(
                    "-" * 70 + "\n"
                )

                if validation_errors:

                    for error in validation_errors:
                        file.write(f"- {error}\n")

                else:

                    file.write(
                        "No validation issues found.\n"
                    )

            logger.info(
                f"Validation report saved: {self.report_path}"
            )

            logger.info(
                "========== DATA VALIDATION COMPLETED =========="
            )

            return DataValidationArtifact(
                validation_status=validation_status,
                validation_report_path=str(self.report_path)
            )

        except Exception as e:

            logger.exception(
                "Error occurred during data validation."
            )

            raise AGDPMException(e, None) from e