from dataclasses import dataclass

import pandas as pd
from sklearn.model_selection import train_test_split

from src.config import (
    CATEGORICAL_FEATURES,
    CLASS_NAMES,
    HOLDOUT_SIZE,
    ID_COLUMN,
    INPUT_FEATURES,
    NUMERIC_FEATURES,
    PROCESSED_DATA_DIR,
    RANDOM_STATE,
    SUBCLASS_COLUMN,
    SUBCLASS_TO_DISORDER,
    SYMPTOM_FEATURES,
    TARGET_COLUMN,
    UNKNOWN_ALIASES,
    UNKNOWN_VALUE,
)
from src.exception import AGDPMException
from src.logger import logger


def clean_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Turn raw patient records into clean model inputs.
    Used for training AND for prediction, so both always match.

    - keeps only the input features (missing columns are added as empty)
    - numbers/symptoms -> numeric (bad values become NaN, imputed later)
    - categories -> trimmed text, all "unknown" spellings -> "Unknown"
    """
    df = df.reindex(columns=INPUT_FEATURES).copy()

    for column in NUMERIC_FEATURES + SYMPTOM_FEATURES:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    for column in CATEGORICAL_FEATURES:
        values = df[column].astype("object")
        values = values.where(values.notna(), UNKNOWN_VALUE)
        values = values.map(lambda value: str(value).strip())
        df[column] = values.replace(
            {alias: UNKNOWN_VALUE for alias in UNKNOWN_ALIASES}
        )

    return df


@dataclass
class DataPreprocessingArtifact:
    X_train: pd.DataFrame
    X_holdout: pd.DataFrame
    y_train: pd.Series
    y_holdout: pd.Series
    X_test: pd.DataFrame
    test_ids: pd.Series


class DataPreprocessing:

    def __init__(self):
        PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)

    def recover_missing_labels(self, df: pd.DataFrame) -> pd.DataFrame:
        recovered = df[SUBCLASS_COLUMN].map(SUBCLASS_TO_DISORDER)
        can_recover = df[TARGET_COLUMN].isna() & recovered.notna()

        df.loc[can_recover, TARGET_COLUMN] = recovered[can_recover]

        logger.info(
            f"Recovered {int(can_recover.sum())} missing labels "
            f"from '{SUBCLASS_COLUMN}'."
        )
        return df

    def initiate_data_preprocessing(
        self,
        train_df: pd.DataFrame,
        test_df: pd.DataFrame
    ) -> DataPreprocessingArtifact:

        logger.info("========== DATA PREPROCESSING STARTED ==========")

        try:
            train_df = train_df.copy()
            test_df = test_df.copy()

            # 1. Completely empty rows carry no information
            train_df = train_df.dropna(how="all")
            test_df = test_df.dropna(how="all")
            logger.info(f"After removing empty rows - train: {train_df.shape}, test: {test_df.shape}")

            # 2. Fill missing labels using the subclass -> disorder mapping
            train_df = self.recover_missing_labels(train_df)

            # 3. Rows that still have no label cannot be used for training
            missing_target = int(train_df[TARGET_COLUMN].isna().sum())
            train_df = train_df.dropna(subset=[TARGET_COLUMN])
            logger.info(f"Removed {missing_target} rows with no label.")

            unexpected = set(train_df[TARGET_COLUMN]) - set(CLASS_NAMES)
            if unexpected:
                raise ValueError(f"Unexpected target values: {unexpected}")

            # 4. Clean features (Patient Id, names, institute, Test 1-5,
            #    parental consent and Disorder Subclass are dropped here)
            X = clean_features(train_df)
            y = train_df[TARGET_COLUMN].reset_index(drop=True)
            X = X.reset_index(drop=True)

            # 5. Remove exact duplicate patients (same features + label)
            duplicated = pd.concat([X, y], axis=1).duplicated()
            X = X[~duplicated].reset_index(drop=True)
            y = y[~duplicated].reset_index(drop=True)
            logger.info(f"Removed {int(duplicated.sum())} duplicate rows.")

            logger.info(f"Class distribution:\n{y.value_counts().to_string()}")

            # 6. Hold back data the model never sees during training
            X_train, X_holdout, y_train, y_holdout = train_test_split(
                X,
                y,
                test_size=HOLDOUT_SIZE,
                stratify=y,
                random_state=RANDOM_STATE,
            )

            # 7. Unlabelled competition test file (prediction only)
            X_test = clean_features(test_df)
            test_ids = test_df[ID_COLUMN].reset_index(drop=True)
            X_test = X_test.reset_index(drop=True)

            logger.info(f"X_train: {X_train.shape}, X_holdout: {X_holdout.shape}, X_test: {X_test.shape}")

            X_train.to_csv(PROCESSED_DATA_DIR / "X_train_clean.csv", index=False)
            y_train.to_csv(PROCESSED_DATA_DIR / "y_train.csv", index=False)
            X_holdout.to_csv(PROCESSED_DATA_DIR / "X_holdout_clean.csv", index=False)
            y_holdout.to_csv(PROCESSED_DATA_DIR / "y_holdout.csv", index=False)
            X_test.to_csv(PROCESSED_DATA_DIR / "X_test_clean.csv", index=False)

            logger.info("========== DATA PREPROCESSING COMPLETED ==========")

            return DataPreprocessingArtifact(
                X_train=X_train.reset_index(drop=True),
                X_holdout=X_holdout.reset_index(drop=True),
                y_train=y_train.reset_index(drop=True),
                y_holdout=y_holdout.reset_index(drop=True),
                X_test=X_test,
                test_ids=test_ids,
            )

        except Exception as e:
            logger.exception("Error occurred during data preprocessing.")
            raise AGDPMException(e, None) from e
