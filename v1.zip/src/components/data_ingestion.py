import shutil
from dataclasses import dataclass

import pandas as pd

from src.config import (
    RAW_TRAIN_FILE,
    RAW_TEST_FILE,
    TRAIN_DATA_FILE,
    TEST_DATA_FILE,
    WORKING_DATA_DIR,
)
from src.exception import AGDPMException
from src.logger import logger


@dataclass
class DataIngestionArtifact:
    train_data: pd.DataFrame
    test_data: pd.DataFrame


class DataIngestion:
    """
    Copies the original dataset from data/raw into data/working
    (only if the copy does not exist yet) and reads the copy.
    The files in data/raw are never modified.
    """

    def copy_raw_data(self):
        WORKING_DATA_DIR.mkdir(parents=True, exist_ok=True)

        for source, destination in [
            (RAW_TRAIN_FILE, TRAIN_DATA_FILE),
            (RAW_TEST_FILE, TEST_DATA_FILE),
        ]:
            if destination.exists():
                logger.info(f"Working copy already exists: {destination}")
            else:
                shutil.copy2(source, destination)
                logger.info(f"Copied {source} -> {destination}")

    def initiate_data_ingestion(self) -> DataIngestionArtifact:

        logger.info("========== DATA INGESTION STARTED ==========")

        try:
            self.copy_raw_data()

            train_df = pd.read_csv(TRAIN_DATA_FILE)
            test_df = pd.read_csv(TEST_DATA_FILE)

            logger.info(f"Training data shape: {train_df.shape}")
            logger.info(f"Testing data shape: {test_df.shape}")

            logger.info("========== DATA INGESTION COMPLETED ==========")

            return DataIngestionArtifact(
                train_data=train_df,
                test_data=test_df,
            )

        except Exception as e:
            logger.exception("Error occurred during data ingestion.")
            raise AGDPMException(e, None) from e
