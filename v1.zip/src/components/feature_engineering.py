import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

from src.config import (
    CATEGORICAL_FEATURES,
    ENGINEERED_NUMERIC_FEATURES,
    GENE_FEATURES,
    NUMERIC_FEATURES,
    SYMPTOM_FEATURES,
)


def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Two simple features that summarise the strongest signals
    in this dataset (symptoms and inherited genes).
    """
    df = df.copy()

    # How many of the 5 symptoms the patient has
    df["Symptom Total"] = df[SYMPTOM_FEATURES].sum(axis=1, min_count=1)

    # How many of the 4 gene questions are answered "Yes"
    df["Inherited Gene Count"] = (df[GENE_FEATURES] == "Yes").sum(axis=1)

    return df


def build_preprocessor() -> Pipeline:
    """
    Feature engineering + imputation + encoding, packaged as one
    sklearn pipeline so it is saved together with the model.
    Input: the output of clean_features().
    """
    numeric_columns = NUMERIC_FEATURES + SYMPTOM_FEATURES + ENGINEERED_NUMERIC_FEATURES

    numeric_pipeline = Pipeline(steps=[
        # add_indicator=True keeps the information "this value was missing"
        ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline(steps=[
        # Missing categories are already "Unknown" after cleaning
        ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])

    column_transformer = ColumnTransformer(transformers=[
        ("numerical", numeric_pipeline, numeric_columns),
        ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
    ])

    return Pipeline(steps=[
        ("feature_engineering", FunctionTransformer(add_engineered_features)),
        ("encoding", column_transformer),
    ])
