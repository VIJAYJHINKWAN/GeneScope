import pandas as pd


# ---------------------------------------
# Load processed training data
# ---------------------------------------

X_train = pd.read_csv(
    "data/processed/X_train_clean.csv"
)

y_train = pd.read_csv(
    "data/processed/y_train.csv"
).squeeze()


# ---------------------------------------
# Create analysis dataframe
# ---------------------------------------

df = X_train.copy()

df["Genetic Disorder"] = y_train.values


# ---------------------------------------
# Class distribution
# ---------------------------------------

print("\n" + "=" * 80)
print("AGDPM CLASS DISTRIBUTION")
print("=" * 80)

class_counts = (
    df["Genetic Disorder"]
    .value_counts()
)

class_percentages = (
    df["Genetic Disorder"]
    .value_counts(normalize=True)
    .mul(100)
)

class_distribution = pd.DataFrame(
    {
        "Count": class_counts,
        "Percentage": class_percentages
    }
)

print(
    class_distribution.to_string()
)


# ---------------------------------------
# Numeric feature analysis
# ---------------------------------------

numeric_columns = X_train.select_dtypes(
    include=["int64", "float64", "int32", "float32"]
).columns.tolist()


print("\n" + "=" * 80)
print("NUMERIC FEATURE CLASS-WISE MEANS")
print("=" * 80)


class_means = (
    df.groupby("Genetic Disorder")[numeric_columns]
    .mean()
    .transpose()
)

print(
    class_means.to_string()
)


# ---------------------------------------
# Numeric feature class-wise standard deviation
# ---------------------------------------

print("\n" + "=" * 80)
print("NUMERIC FEATURE CLASS-WISE STANDARD DEVIATION")
print("=" * 80)


class_std = (
    df.groupby("Genetic Disorder")[numeric_columns]
    .std()
    .transpose()
)

print(
    class_std.to_string()
)


# ---------------------------------------
# Save results
# ---------------------------------------

class_distribution.to_csv(
    "artifacts/class_distribution.csv"
)

class_means.to_csv(
    "artifacts/class_feature_means.csv"
)

class_std.to_csv(
    "artifacts/class_feature_std.csv"
)


print("\nResults saved:")
print("artifacts/class_distribution.csv")
print("artifacts/class_feature_means.csv")
print("artifacts/class_feature_std.csv")