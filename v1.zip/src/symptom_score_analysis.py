import pandas as pd


# ---------------------------------------
# Load processed training data
# ---------------------------------------

X_train = pd.read_csv(
    "data/processed/X_train_clean.csv"
)

y_train = pd.read_csv(
    "data/processed/y_train.csv"
).squeeze()


# ---------------------------------------
# Symptom columns
# ---------------------------------------

symptom_columns = [
    "Symptom 1",
    "Symptom 2",
    "Symptom 3",
    "Symptom 4",
    "Symptom 5"
]


# ---------------------------------------
# Convert symptoms to numeric
# ---------------------------------------

for column in symptom_columns:
    X_train[column] = pd.to_numeric(
        X_train[column],
        errors="coerce"
    )


# ---------------------------------------
# Create Total Symptom Score
# ---------------------------------------

X_train["Total Symptom Score"] = (
    X_train[symptom_columns]
    .sum(axis=1, min_count=1)
)


# ---------------------------------------
# Add target
# ---------------------------------------

X_train["Genetic Disorder"] = y_train.values


# ---------------------------------------
# Analyze score by class
# ---------------------------------------

score_analysis = (
    X_train
    .groupby("Genetic Disorder")["Total Symptom Score"]
    .agg(
        [
            "count",
            "mean",
            "std",
            "min",
            "max"
        ]
    )
)


# ---------------------------------------
# Display results
# ---------------------------------------

print("\n" + "=" * 80)
print("AGDPM TOTAL SYMPTOM SCORE ANALYSIS")
print("=" * 80)

print(
    score_analysis.to_string()
)


# ---------------------------------------
# Score distribution
# ---------------------------------------

print("\n" + "=" * 80)
print("TOTAL SYMPTOM SCORE DISTRIBUTION")
print("=" * 80)

score_distribution = pd.crosstab(
    X_train["Total Symptom Score"],
    X_train["Genetic Disorder"],
    normalize="index"
).mul(100)

print(
    score_distribution.to_string()
)


# ---------------------------------------
# Save results
# ---------------------------------------

score_analysis.to_csv(
    "artifacts/total_symptom_score_analysis.csv"
)

score_distribution.to_csv(
    "artifacts/total_symptom_score_distribution.csv"
)


print("\nResults saved:")
print("artifacts/total_symptom_score_analysis.csv")
print("artifacts/total_symptom_score_distribution.csv")