import io
import json
from typing import Any

import pandas as pd
from fastapi import Body, FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from src.config import (
    CATEGORICAL_FEATURES,
    ID_COLUMN,
    INPUT_FEATURES,
    METRICS_FILE,
    NUMERIC_FEATURES,
    PROCESSED_DATA_DIR,
    PROJECT_ROOT,
    SYMPTOM_FEATURES,
    UNKNOWN_VALUE,
)
from src.pipeline.predict_pipeline import PredictPipeline


STATIC_DIR = PROJECT_ROOT / "app" / "static"
MAX_BATCH_ROWS = 20000

app = FastAPI(title="Genetic Disorder Predictor API", version="1.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

predictor = PredictPipeline()


def validate_patient(patient: dict[str, Any]) -> dict[str, Any]:
    """Keep known fields only and reject values the model cannot use."""
    fields = predictor.model_info["fields"]
    clean = {}
    errors = []

    for column in INPUT_FEATURES:
        value = patient.get(column)

        if value is None or value == "":
            clean[column] = None
            continue

        if column in NUMERIC_FEATURES or column in SYMPTOM_FEATURES:
            try:
                value = float(value)
            except (TypeError, ValueError):
                errors.append(f"'{column}' must be a number.")
                continue

            if column in SYMPTOM_FEATURES and value not in (0, 1):
                errors.append(f"'{column}' must be 0 or 1.")
            elif column in NUMERIC_FEATURES and value < 0:
                errors.append(f"'{column}' cannot be negative.")

        elif column in CATEGORICAL_FEATURES:
            options = fields[column]["options"]
            if value not in options and value != UNKNOWN_VALUE:
                errors.append(f"'{column}' must be one of {options}.")

        clean[column] = value

    if errors:
        raise HTTPException(status_code=422, detail=errors)

    return clean


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
def health():
    return {"status": "ok", "model": predictor.model_info["model_name"]}


@app.get("/api/model-info")
def model_info():
    return predictor.model_info


@app.get("/api/metrics")
def metrics():
    with open(METRICS_FILE, encoding="utf-8") as file:
        return json.load(file)


@app.get("/api/sample")
def sample_patient():
    """A random patient from the holdout set (not used in training), for demos."""
    X = pd.read_csv(PROCESSED_DATA_DIR / "X_holdout_clean.csv")
    y = pd.read_csv(PROCESSED_DATA_DIR / "y_holdout.csv").squeeze("columns")

    index = int(pd.Series(range(len(X))).sample(1).iloc[0])
    row = X.iloc[index].astype(object).where(X.iloc[index].notna(), None).to_dict()

    return {"patient": row, "actual": y.iloc[index]}


@app.post("/api/predict")
def predict(patient: dict[str, Any] = Body(...)):
    return predictor.predict_one(validate_patient(patient))


@app.post("/api/predict-batch")
async def predict_batch(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Please upload a .csv file.")

    try:
        df = pd.read_csv(io.BytesIO(await file.read()))
    except Exception:
        raise HTTPException(status_code=400, detail="Could not read the CSV file.")

    df = df.dropna(how="all")

    if df.empty:
        raise HTTPException(status_code=400, detail="The CSV file has no rows.")
    if len(df) > MAX_BATCH_ROWS:
        raise HTTPException(status_code=400, detail=f"Maximum {MAX_BATCH_ROWS} rows per file.")

    matched = [column for column in INPUT_FEATURES if column in df.columns]
    if not matched:
        raise HTTPException(
            status_code=400,
            detail="No known feature columns found. Use the same column names as the dataset.",
        )

    predictions = predictor.predict_dataframe(df)
    ids = df[ID_COLUMN].tolist() if ID_COLUMN in df.columns else list(range(1, len(df) + 1))

    return {
        "rows": len(predictions),
        "matched_columns": len(matched),
        "total_columns": len(INPUT_FEATURES),
        "results": [
            {"id": str(patient_id), **prediction}
            for patient_id, prediction in zip(ids, predictions)
        ],
    }
